Param(
    [string]$To = "",
    [string]$From = "",
    [string]$Subject = "LoucurasStream - Downloads (APK, IPA, EXE)",
    [string]$SmtpServer = $env:SMTP_SERVER,
    [int]$SmtpPort = $env:SMTP_PORT,
    [string]$SmtpUser = $env:SMTP_USER,
    [string]$SmtpPass = $env:SMTP_PASS
)

Write-Host "=== LoucurasStream Antifalhas & Email ===" -ForegroundColor Cyan

$base = Split-Path -Parent $PSCommandPath
$downloads = Join-Path $base "downloads"

if (-not (Test-Path $downloads)) {
    Write-Host "Criando pasta de downloads..." -ForegroundColor Yellow
    New-Item -ItemType Directory -Path $downloads | Out-Null
}

$files = @(
    Join-Path $downloads "LoucurasStream.apk",
    Join-Path $downloads "LoucurasStream.ipa",
    Join-Path $downloads "LoucurasStream.exe"
)

$allOk = $true
foreach ($f in $files) {
    if (-not (Test-Path $f)) {
        Write-Host "Arquivo ausente: $f" -ForegroundColor Red
        $allOk = $false
    } else {
        $size = (Get-Item $f).Length
        $hash = (Get-FileHash -Algorithm SHA256 -Path $f).Hash
        Write-Host ("OK: {0} | Tamanho: {1} bytes | SHA256: {2}" -f (Split-Path $f -Leaf), $size, $hash) -ForegroundColor Green
        if ($size -le 0) {
            Write-Host "Arquivo vazio: $f" -ForegroundColor Red
            $allOk = $false
        }
    }
}

$zipPath = Join-Path $base "LoucurasStream_Kit.zip"
try {
    if (Test-Path $zipPath) { Remove-Item -Force $zipPath }
    Write-Host "Compactando arquivos em: $zipPath" -ForegroundColor Yellow
    Compress-Archive -Path $files -DestinationPath $zipPath -Force
    Write-Host "Zip criado com sucesso." -ForegroundColor Green
} catch {
    Write-Host "Falha ao criar o zip: $($_.Exception.Message)" -ForegroundColor Red
    $allOk = $false
}

if (-not $To) {
    $To = Read-Host "Digite o email de destino (To)"
}
if (-not $From) {
    $From = Read-Host "Digite o email de origem (From)"
}

if ($SmtpServer -and $SmtpPort -and $SmtpUser -and $SmtpPass) {
    try {
        Write-Host "Enviando email via SMTP..." -ForegroundColor Yellow
        $securePass = ConvertTo-SecureString $SmtpPass -AsPlainText -Force
        $cred = New-Object System.Management.Automation.PSCredential ($SmtpUser, $securePass)

        $mail = New-Object System.Net.Mail.MailMessage
        $mail.From = $From
        $mail.To.Add($To)
        $mail.Subject = $Subject
        $mail.Body = "Segue em anexo o kit LoucurasStream (APK, IPA, EXE) com verificação."
        $mail.Attachments.Add((New-Object System.Net.Mail.Attachment($zipPath)))

        $client = New-Object System.Net.Mail.SmtpClient($SmtpServer, $SmtpPort)
        $client.EnableSsl = $true
        $client.Credentials = New-Object System.Net.NetworkCredential($SmtpUser, $SmtpPass)
        $client.Send($mail)

        Write-Host "Email enviado com sucesso para $To" -ForegroundColor Green
    } catch {
        Write-Host "Falha ao enviar email: $($_.Exception.Message)" -ForegroundColor Red
        $allOk = $false
    }
} else {
    Write-Host "SMTP não configurado. Configure as variáveis de ambiente: SMTP_SERVER, SMTP_PORT, SMTP_USER, SMTP_PASS" -ForegroundColor Yellow
    Write-Host "Abrindo pasta de downloads para envio manual..." -ForegroundColor Yellow
    Start-Process explorer.exe $base
    $mailto = "mailto:$To?subject=$([uri]::EscapeDataString($Subject))&body=$([uri]::EscapeDataString('Anexe o arquivo LoucurasStream_Kit.zip em: ' + $zipPath))"
    Start-Process $mailto
}

if ($allOk) {
    Write-Host "Processo concluído sem falhas." -ForegroundColor Green
} else {
    Write-Host "Concluído com avisos/erros. Verifique as mensagens acima." -ForegroundColor Yellow
}
