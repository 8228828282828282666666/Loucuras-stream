LoucurasStream • Pacote Universal v0.2.3.3

Conteúdo:
- App JS (Web) com resgate lkprodbt, anúncios e pagamento
- Backend local (Python) para cadastro/distribuição/pagamento com proprietário
- Artefatos: APK (Flet/JS), EXE (Flet/JS), IPA (Flet/JS ou ZIP build)

Como iniciar (Windows):
- Execute run_backend.bat para iniciar API na porta 8787
- Abra js_app/index.html (ou use FG Store) e faça login Google
- Resgate lkprodbt para ativar Premium até 31/01/2026
- Após vencimento, use pagamento por cartão (simulado) para estender 1 mês

Compatibilidade:
- Windows 8/9/10/11/12
- macOS (Web App e build iOS disponível)
- iPhone 11/12/13/14/15/16 (instalação via IPA quando assinado)
- Android (Moto e Samsung de A20 até A75, e demais modelos)
- Chromebook: disponível em 22/03/2026 (instalação via PWA/ZIP)

Propriedade:
- Somente o dono da conta (email Google) tem acesso para operar (owner)
- Configure google_config.json com seu client_id para login Google
