# LoucurasStream

Um aplicativo de streaming de música 100% gratuito feito em Python.

## Pré-requisitos

- Python 3.7 ou superior instalado.
- Conexão com a internet.

## Instalação

1. Abra o terminal ou prompt de comando na pasta do projeto.
2. Instale as dependências:

```bash
pip install -r requirements.txt
```

## Como rodar

Execute o arquivo `main.py`:

```bash
python main.py
```

## Funcionalidades

- Busca de músicas, artistas e álbuns (via YouTube Music).
- Streaming de áudio direto (via YouTube).
- Interface moderna e responsiva.
