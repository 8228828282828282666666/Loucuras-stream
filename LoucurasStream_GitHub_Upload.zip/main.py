import flet as ft
from ytmusicapi import YTMusic
import yt_dlp
import threading
import os
import json
from datetime import datetime
import random

# Inicializa a API do YouTube Music
yt = YTMusic()

# Mock de Banco de Dados
USER_DB_FILE = "users.json"
DISTRIBUTION_DB_FILE = "distribution.json"
LYRICS_DB_FILE = "lyrics.json"
PAYMENTS_DB_FILE = "payments.json"

def get_stream_url(video_id):
    """
    Obtém a URL direta de áudio usando yt-dlp.
    """
    ydl_opts = {
        'format': 'bestaudio/best',
        'quiet': True,
        'noplaylist': True,
    }
    with yt_dlp.YoutubeDL(ydl_opts) as ydl:
        try:
            # Extrai informações do vídeo
            info = ydl.extract_info(f"https://www.youtube.com/watch?v={video_id}", download=False)
            return info.get('url')
        except Exception as e:
            print(f"Erro ao extrair URL: {e}")
            raise e

def save_user(user_data):
    users = []
    if os.path.exists(USER_DB_FILE):
        with open(USER_DB_FILE, 'r') as f:
            try: users = json.load(f)
            except: pass
    users.append(user_data)
    with open(USER_DB_FILE, 'w') as f:
        json.dump(users, f)

def save_distribution(dist_data):
    items = []
    if os.path.exists(DISTRIBUTION_DB_FILE):
        with open(DISTRIBUTION_DB_FILE, 'r') as f:
            try: items = json.load(f)
            except: pass
    items.append(dist_data)
    with open(DISTRIBUTION_DB_FILE, 'w') as f:
        json.dump(items, f)

def save_lyrics(lyrics_data):
    items = []
    if os.path.exists(LYRICS_DB_FILE):
        with open(LYRICS_DB_FILE, 'r') as f:
            try: items = json.load(f)
            except: pass
    items.append(lyrics_data)
    with open(LYRICS_DB_FILE, 'w') as f:
        json.dump(items, f)

def save_payment(payment_data):
    items = []
    if os.path.exists(PAYMENTS_DB_FILE):
        with open(PAYMENTS_DB_FILE, 'r') as f:
            try: items = json.load(f)
            except: pass
    items.append(payment_data)
    with open(PAYMENTS_DB_FILE, 'w') as f:
        json.dump(items, f)
def main(page: ft.Page):
    page.title = "LoucurasStream - GRTC Filmes Records"
    page.theme_mode = ft.ThemeMode.DARK
    page.padding = 20
    page.window_width = 400
    page.window_height = 800

    # Variáveis de Estado
    current_user = None

    # --- TELAS ---
    
    def show_ggost():
        def proceed(e):
            page.dialog.open = False
            page.update()
        page.dialog = ft.AlertDialog(
            title=ft.Text("GGOST"),
            content=ft.Text("Bem-vindo. Continue para cadastro e escolha seu perfil."),
            actions=[ft.TextButton("Continuar", on_click=proceed)],
            actions_alignment=ft.MainAxisAlignment.END,
        )
        page.dialog.open = True
        page.update()

    def login_screen():
        name_field = ft.TextField(label="Nome Completo", border_radius=10)
        email_field = ft.TextField(label="Email", border_radius=10)
        pass_field = ft.TextField(label="Senha (min 10 dígitos)", password=True, can_reveal_password=True, border_radius=10)
        plan_checkbox = ft.Checkbox(label="Plano sem anúncios (R$ 5/mês)")
        
        role_dropdown = ft.Dropdown(
            label="Você é:",
            options=[
                ft.dropdown.Option("Ouvinte"),
                ft.dropdown.Option("DJ"),
                ft.dropdown.Option("Cantor"),
                ft.dropdown.Option("Gravadora"),
                ft.dropdown.Option("Compositor"),
                ft.dropdown.Option("Letrista"),
            ],
            border_radius=10
        )

        yt_link_field = ft.TextField(label="Seu Canal do YouTube (Link)", border_radius=10, visible=False)
        grtc_link_field = ft.TextField(label="Link GRTC Filmes Records", value="https://youtube.com/@grtcfilmesrecords", read_only=True, border_radius=10)

        def on_role_change(e):
            if role_dropdown.value in ["DJ", "Cantor", "Gravadora"]:
                yt_link_field.visible = True
            else:
                yt_link_field.visible = False
            page.update()

        role_dropdown.on_change = on_role_change

        def register_click(e):
            if len(pass_field.value) < 10:
                page.snack_bar = ft.SnackBar(ft.Text("A senha deve ter pelo menos 10 dígitos!"))
                page.snack_bar.open = True
                page.update()
                return
            
            nonlocal current_user
            current_user = {
                "name": name_field.value,
                "email": email_field.value,
                "role": role_dropdown.value,
                "yt_link": yt_link_field.value,
                "plan": {"no_ads": plan_checkbox.value, "price": 5}
            }
            save_user(current_user)
            
            page.clean()
            app_layout()

        return ft.Column([
            ft.Text("Bem-vindo ao LoucurasStream", size=24, weight="bold", color="purple"),
            ft.Text("Powered by GRTC Filmes Records", size=12, color="grey"),
            ft.Divider(),
            name_field,
            email_field,
            pass_field,
            role_dropdown,
            yt_link_field,
            grtc_link_field,
            plan_checkbox,
            ft.ElevatedButton("Criar Conta e Entrar", on_click=register_click, width=200, style=ft.ButtonStyle(bgcolor="purple", color="white"))
        ], alignment=ft.MainAxisAlignment.CENTER, horizontal_alignment=ft.CrossAxisAlignment.CENTER, spacing=20)


    # 2. Layout Principal do App
    def app_layout():
        # Player Setup
        audio_player = ft.Audio(autoplay=True)
        page.overlay.append(audio_player)
        is_playing = [False]

        # UI Components
        song_title = ft.Text("Nenhuma música tocando", weight=ft.FontWeight.BOLD, size=14, no_wrap=True)
        song_artist = ft.Text("", size=12, no_wrap=True, color=ft.colors.GREY_400)
        
        play_pause_btn = ft.IconButton(icon=ft.icons.PLAY_ARROW)

        def toggle_playback(e):
            if is_playing[0]:
                audio_player.pause()
                play_pause_btn.icon = ft.icons.PLAY_ARROW
                is_playing[0] = False
            else:
                audio_player.resume()
                play_pause_btn.icon = ft.icons.PAUSE
                is_playing[0] = True
            play_pause_btn.update()

        play_pause_btn.on_click = toggle_playback

        player_bar = ft.Container(
            content=ft.Row(
                controls=[
                    ft.Column([song_title, song_artist], expand=True, spacing=2, alignment=ft.MainAxisAlignment.CENTER),
                    play_pause_btn
                ],
                alignment=ft.MainAxisAlignment.SPACE_BETWEEN,
            ),
            padding=ft.padding.symmetric(horizontal=15, vertical=10),
            bgcolor=ft.colors.SURFACE_VARIANT,
            border_radius=15,
            visible=False,
            margin=ft.margin.only(bottom=10)
        )

        def play_song(video_id, title, artist):
            song_title.value = title
            song_artist.value = artist
            player_bar.visible = True
            play_pause_btn.icon = ft.icons.PAUSE
            play_pause_btn.disabled = True
            is_playing[0] = True
            page.update()

            def load_and_play():
                try:
                    url = get_stream_url(video_id)
                    audio_player.src = url
                    audio_player.update()
                    play_pause_btn.disabled = False
                    play_pause_btn.update()
                except Exception as e:
                    print(f"Erro: {e}")
                    play_pause_btn.disabled = False
                    play_pause_btn.icon = ft.icons.ERROR
                    play_pause_btn.update()

            threading.Thread(target=load_and_play, daemon=True).start()

        # --- ABAS ---
        
        # Aba 1: Busca (Player)
        search_query = ft.TextField(hint_text="Buscar música...", expand=True, on_submit=lambda e: search_music(e.control.value))
        results_view = ft.Column(scroll=ft.ScrollMode.AUTO, expand=True)

        def search_music(query):
            if not query: return
            results_view.controls.clear()
            results_view.controls.append(ft.ProgressBar())
            page.update()

            def task():
                try:
                    results = yt.search(query, filter="songs")
                    items = []
                    for song in results:
                        title = song.get('title', 'Unknown')
                        artists = ", ".join([a['name'] for a in song.get('artists', [])])
                        vid = song.get('videoId')
                        thumb = song.get('thumbnails', [{}])[0].get('url', '')
                        
                        if vid:
                            items.append(ft.Container(
                                content=ft.Row([
                                    ft.Image(src=thumb, width=50, height=50, border_radius=8),
                                    ft.Column([ft.Text(title, weight="bold"), ft.Text(artists, size=12)], expand=True),
                                    ft.Icon(ft.icons.PLAY_CIRCLE)
                                ]),
                                padding=10, ink=True, border_radius=10,
                                on_click=lambda e, v=vid, t=title, a=artists: play_song(v, t, a)
                            ))
                    results_view.controls.clear()
                    results_view.controls.extend(items)
                except Exception as e:
                    results_view.controls.clear()
                    results_view.controls.append(ft.Text(f"Erro: {e}"))
                page.update()
            
            threading.Thread(target=task, daemon=True).start()

        tab_search = ft.Column([
            ft.Row([search_query, ft.IconButton(ft.icons.SEARCH, on_click=lambda e: search_music(search_query.value))]),
            results_view
        ])

        # Aba 2: Spotify Import (Simulado)
        spotify_link = ft.TextField(label="Link da Playlist do Spotify", expand=True)
        spotify_status = ft.Text()
        
        def import_spotify(e):
            spotify_status.value = "Importando metadados... (Simulação)"
            spotify_status.color = "green"
            page.update()
            time.sleep(2)
            spotify_status.value = "Músicas vinculadas com sucesso ao catálogo da Tera!"
            page.update()

        tab_spotify = ft.Column([
            ft.Text("Migrar do Spotify", size=20, weight="bold"),
            ft.Text("Transfira suas músicas e vincule à plataforma."),
            ft.Row([spotify_link, ft.ElevatedButton("Importar", on_click=import_spotify)]),
            spotify_status
        ], spacing=20)

        # Aba 3: Distribuição (Tera / GRTC)
        dist_title = ft.TextField(label="Título da Música/Vídeo")
        dist_file = ft.FilePicker()
        page.overlay.append(dist_file)
        
        dist_date = ft.TextField(label="Data de Lançamento (DD/MM/AAAA)")
        dist_status = ft.Text()

        def distribute_content(e):
            if not dist_title.value or not dist_date.value:
                dist_status.value = "Preencha todos os campos."
                dist_status.color = "red"
                page.update()
                return
            
            data = {
                "user": current_user['name'],
                "title": dist_title.value,
                "date": dist_date.value,
                "label": "GRTC Filmes Records",
                "distributor": "Tera",
                "timestamp": str(datetime.now())
            }
            save_distribution(data)
            
            dist_status.value = f"Enviado para Tera Distributor! Lançamento agendado para {dist_date.value}."
            dist_status.color = "green"
            dist_title.value = ""
            page.update()

        tab_dist = ft.Column([
            ft.Text("Distribuição Tera (Grátis)", size=20, weight="bold"),
            ft.Text("Distribua para todas as plataformas e YouTube (Canal Próprio + GRTC)."),
            dist_title,
            dist_date,
            ft.ElevatedButton("Selecionar Arquivo de Áudio/Vídeo", on_click=lambda _: dist_file.pick_files()),
            ft.ElevatedButton("Distribuir Agora", on_click=distribute_content, bgcolor="blue", color="white"),
            dist_status
        ], spacing=20)

        lyrics_title = ft.TextField(label="Título da Música")
        lyrics_text = ft.TextField(label="Letra (Argusta Plow TV)", multiline=True, min_lines=6, max_lines=12)
        lyrics_status = ft.Text()

        def save_lyrics_click(e):
            data = {
                "user": current_user['name'] if current_user else "",
                "title": lyrics_title.value,
                "lyrics": lyrics_text.value or "",
                "tool": "Argusta Plow TV",
                "timestamp": str(datetime.now())
            }
            save_lyrics(data)
            lyrics_status.value = "Letra registrada."
            lyrics_status.color = "green"
            lyrics_title.value = ""
            lyrics_text.value = ""
            page.update()

        tab_argusta = ft.Column([
            ft.Text("Argusta Plow TV", size=20, weight="bold"),
            lyrics_title,
            lyrics_text,
            ft.ElevatedButton("Salvar Letra", on_click=save_lyrics_click),
            lyrics_status
        ], spacing=20)

        plan_info = ft.Text("")
        if current_user and current_user.get("plan", {}).get("no_ads"):
            plan_info.value = "Plano sem anúncios ativo (R$ 5/mês)"
            plan_info.color = "green"

        newcard_status = ft.Text()
        discount_status = ft.Text()
        pix_status = ft.Text()

        newcard_name = ft.TextField(label="Nome no Cartão", value=(current_user['name'] if current_user else ""), expand=True)

        newcard_number_text = ft.Text("", color="black", size=18)
        newcard_holder_text = ft.Text("", color="black")
        newcard_expiry_text = ft.Text("", color="black")

        card_view = ft.Container(
            bgcolor=ft.colors.WHITE,
            border_radius=16,
            padding=20,
            content=ft.Column([
                ft.Text("NEWCARD", color="black", size=20, weight=ft.FontWeight.BOLD),
                newcard_number_text,
                ft.Row([ft.Text("Titular:", color="black"), newcard_holder_text]),
                ft.Row([ft.Text("Validade:", color="black"), newcard_expiry_text]),
            ], spacing=8),
        )

        def generate_card(e):
            num = "".join([str(random.randint(0,9)) for _ in range(16)])
            grouped = " ".join([num[i:i+4] for i in range(0,16,4)])
            expiry = f"{datetime.now().month:02d}/{(datetime.now().year+4)%100:02d}"
            newcard_number_text.value = grouped
            newcard_holder_text.value = newcard_name.value or ""
            newcard_expiry_text.value = expiry
            save_payment({
                "type": "newcard",
                "holder": newcard_name.value or "",
                "last4": num[-4:],
                "created_at": str(datetime.now())
            })
            newcard_status.value = "Cartão virtual gerado."
            newcard_status.color = "green"
            page.update()

        discount_name = ft.TextField(label="Nome para Cartão de Desconto", value=(current_user['name'] if current_user else ""), expand=True)

        def request_discount(e):
            save_payment({
                "type": "discount_card_request",
                "name": discount_name.value or "",
                "requested_at": str(datetime.now())
            })
            discount_status.value = "Solicitação enviada."
            discount_status.color = "green"
            page.update()

        pix_key_text = ft.Text("Chave PIX: 47992504167")

        def copy_pix(e):
            try:
                page.set_clipboard("47992504167")
                pix_status.value = "Chave PIX copiada."
                pix_status.color = "green"
            except:
                pix_status.value = "Falha ao copiar. Use manualmente."
                pix_status.color = "red"
            page.update()

        def confirm_pix(e):
            save_payment({
                "type": "pix_payment",
                "key": "47992504167",
                "amount": 5,
                "confirmed_at": str(datetime.now())
            })
            if current_user:
                current_user["plan"] = {"no_ads": True, "price": 5}
                plan_info.value = "Plano sem anúncios ativo (R$ 5/mês)"
                plan_info.color = "green"
            pix_status.value = "Pagamento confirmado."
            pix_status.color = "green"
            page.update()

        tab_payment = ft.Column([
            ft.Text("Pagamento", size=20, weight=ft.FontWeight.BOLD),
            ft.Container(
                content=ft.Column([
                    ft.Text("Cartão Virtual NEWCARD", weight=ft.FontWeight.BOLD),
                    newcard_name,
                    card_view,
                    ft.Row([ft.ElevatedButton("Gerar Cartão Virtual", on_click=generate_card)], alignment=ft.MainAxisAlignment.END),
                    newcard_status,
                ], spacing=10),
                padding=15,
                border_radius=12,
                bgcolor=ft.colors.SURFACE_VARIANT
            ),
            ft.Container(
                content=ft.Column([
                    ft.Text("Cartão de Desconto", weight=ft.FontWeight.BOLD),
                    discount_name,
                    ft.Row([ft.ElevatedButton("Solicitar Cartão de Desconto", on_click=request_discount)], alignment=ft.MainAxisAlignment.END),
                    discount_status,
                ], spacing=10),
                padding=15,
                border_radius=12,
                bgcolor=ft.colors.SURFACE_VARIANT
            ),
            ft.Container(
                content=ft.Column([
                    ft.Text("Pagamento por PIX", weight=ft.FontWeight.BOLD),
                    pix_key_text,
                    ft.Row([
                        ft.OutlinedButton("Copiar Chave", on_click=copy_pix),
                        ft.ElevatedButton("Confirmar Pagamento R$ 5", on_click=confirm_pix),
                    ]),
                    pix_status,
                ], spacing=10),
                padding=15,
                border_radius=12,
                bgcolor=ft.colors.SURFACE_VARIANT
            ),
        ], spacing=20)

        # Tabs Setup
        t = ft.Tabs(
            selected_index=0,
            animation_duration=300,
            tabs=[
                ft.Tab(text="Player", icon=ft.icons.MUSIC_NOTE, content=tab_search),
                ft.Tab(text="Spotify", icon=ft.icons.SYNC, content=tab_spotify),
                ft.Tab(text="Distribuir", icon=ft.icons.UPLOAD, content=tab_dist),
                ft.Tab(text="Argusta", icon=ft.icons.TEXT_SNIPPET, content=tab_argusta),
                ft.Tab(text="Pagamento", icon=ft.icons.PAYMENTS, content=tab_payment),
            ],
            expand=True,
        )

        page.add(plan_info, t, player_bar)

    # Inicia na tela de login
    page.add(login_screen())
    show_ggost()

if __name__ == "__main__":
    if 'PORT' in os.environ:
        ft.app(target=main, view=ft.AppView.WEB_BROWSER, port=int(os.environ.get("PORT")), host="0.0.0.0")
    else:
        ft.app(target=main)
