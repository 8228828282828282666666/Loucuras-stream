local base = arg[1] or "."
local gen = base .. "/generator"
local out = base .. "/downloads"
os.execute("mkdir \"" .. out .. "\"")
local function readfile(p)
  local f = io.open(p, "rb")
  if not f then return nil end
  local d = f:read("*a")
  f:close()
  return d
end
local function writefile(p, d)
  local f = io.open(p, "wb")
  if not f then return end
  f:write(d)
  f:close()
end
local function trycopy(a, b)
  local d = readfile(a)
  if d then writefile(b, d) return true end
  return false
end
local ok = trycopy(gen .. "/buid.exe", out .. "/LoucurasStream.exe") or trycopy(gen .. "/build.exe", out .. "/LoucurasStream.exe")
ok = trycopy(gen .. "/buid.sdk", out .. "/LoucurasStream.apk") or trycopy(gen .. "/build.sdk", out .. "/LoucurasStream.apk")
ok = trycopy(gen .. "/buid.ipa", out .. "/LoucurasStream.ipa") or trycopy(gen .. "/build.ipa", out .. "/LoucurasStream.ipa")
local info = "lua_generated=true\ntimestamp=" .. os.date("!%Y-%m-%dT%H:%M:%SZ")
writefile(out .. "/generator_info_lua.txt", info)
