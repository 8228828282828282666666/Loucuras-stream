# Como criar o APK do LoucurasStream

Como o processo de criação de um APK exige ferramentas pesadas (Android SDK, Java, Flutter) que podem ser difíceis de configurar localmente, preparei um fluxo automatizado para você criar o APK gratuitamente usando o GitHub.

## Passo a Passo

1.  **Crie uma conta no GitHub** (se não tiver).
2.  **Crie um novo repositório** no GitHub.
3.  **Faça o upload dos arquivos** desta pasta para o seu repositório.
    - Você pode usar o Git ou apenas arrastar os arquivos para a interface web do GitHub.
4.  **Acesse a aba "Actions"** no seu repositório no GitHub.
5.  Você verá um workflow chamado "Build Android APK".
6.  Se ele não iniciar automaticamente, clique nele e depois em "Run workflow".
7.  Aguarde o processo terminar (leva cerca de 5-10 minutos).
8.  Quando terminar, clique na execução (que terá um check verde ✅).
9.  Role até a seção **Artifacts** e baixe o arquivo `loucuras-stream-apk`.
10. Dentro do arquivo zip baixado estará o seu aplicativo Android pronto para instalar!

## Observações

-   O APK gerado não é assinado digitalmente para a Play Store, mas funciona perfeitamente instalando manualmente no celular (pode ser necessário ativar "Fontes Desconhecidas").
-   O app precisa de internet para funcionar.

## Se quiser tentar rodar localmente (Avançado)

Se você tiver Flutter e Android SDK configurados:

```bash
flet build apk
```
