const planKey = 'js_plan';
const premiumUntilKey = 'js_premium_until';
const adsEnabledKey = 'js_ads_enabled';
function toDateISO(d){return d.toISOString();}
function parseDateISO(s){return new Date(s);}
function setPremiumUntil(date){
  localStorage.setItem(premiumUntilKey, toDateISO(date));
  localStorage.setItem(planKey, 'paid');
  localStorage.setItem(adsEnabledKey, 'false');
}
function setBasic(){
  localStorage.setItem(planKey, 'basic');
  localStorage.setItem(adsEnabledKey, 'true');
}
function updatePlanState(){
  const el = document.getElementById('plan_state');
  const s = localStorage.getItem(premiumUntilKey);
  const now = new Date();
  if (s){
    const until = parseDateISO(s);
    if (until.getTime() > now.getTime()){
      el.textContent = 'Plano: Premium até ' + until.toLocaleDateString('pt-BR');
      return true;
    }
  }
  const p = localStorage.getItem(planKey);
  if (p === 'paid'){
    el.textContent = 'Plano: Premium vencido, necessário pagamento';
  } else {
    el.textContent = 'Plano: Básico com anúncios';
  }
  return false;
}
function startAdsLoop(){
  const overlay = document.getElementById('ads_overlay');
  function cycle(){
    const enabled = localStorage.getItem(adsEnabledKey) !== 'false';
    const premium = updatePlanState();
    if (!premium && enabled){
      overlay.style.display = 'flex';
      setTimeout(()=>{overlay.style.display='none';}, 1500);
    }
  }
  setInterval(cycle, 5000);
}
function redeemCode(){
  const code = (document.getElementById('promo_code').value||'').trim().toLowerCase();
  const statusEl = document.getElementById('redeem_status');
  if (code === 'lkprodbt'){
    const expiry = new Date('2026-01-31T23:59:59Z');
    setPremiumUntil(expiry);
    statusEl.textContent = 'Código aplicado. Premium até 31/01/2026.';
    updatePlanState();
  } else {
    statusEl.style.color = '#f33';
    statusEl.textContent = 'Código inválido.';
  }
}
async function payWithCard(){
  const name = document.getElementById('cc_name').value;
  const num = document.getElementById('cc_num').value;
  const exp = document.getElementById('cc_exp').value;
  const cvv = document.getElementById('cc_cvv').value;
  const statusEl = document.getElementById('pay_status');
  if (!name || !num || !exp || !cvv){
    statusEl.style.color = '#f33';
    statusEl.textContent = 'Preencha todos os campos.';
    return;
  }
  try{
    const userEmail = localStorage.getItem('js_user_email')||'';
    const r = await fetch('http://127.0.0.1:8787/api/pay', {
      method: 'POST',
      headers: {'Content-Type':'application/json','X-User-Email':userEmail},
      body: JSON.stringify({name, num, exp, cvv, amount: 5})
    });
    const j = await r.json();
    if (j && j.ok){
      const now = new Date();
      now.setMonth(now.getMonth()+1);
      setPremiumUntil(now);
      statusEl.textContent = 'Pagamento aprovado. Premium estendido por 1 mês.';
      updatePlanState();
    } else {
      statusEl.style.color = '#f33';
      statusEl.textContent = 'Pagamento recusado.';
    }
  } catch(e){
    statusEl.style.color = '#f33';
    statusEl.textContent = 'Backend indisponível.';
  }
}
function init(){
  if (!localStorage.getItem(planKey)) setBasic();
  updatePlanState();
  startAdsLoop();
  document.getElementById('redeem_btn').onclick = redeemCode;
  document.getElementById('pay_btn').onclick = payWithCard;
  document.getElementById('play_btn').onclick = ()=>{
    const el = document.getElementById('player_status');
    el.textContent = 'Reprodução iniciada.';
  };
  initGoogle();
}
document.addEventListener('DOMContentLoaded', init);

async function initGoogle(){
  const statusEl = document.getElementById('google_status');
  try{
    const cfg = await fetch('google_config.json').then(r=>r.json()).catch(()=>({client_id:''}));
    if (!cfg.client_id){
      statusEl.style.color = '#f33';
      statusEl.textContent = 'Defina client_id em google_config.json para login Google.';
      return;
    }
    window.google.accounts.id.initialize({
      client_id: cfg.client_id,
      callback: handleCredentialResponse
    });
    window.google.accounts.id.renderButton(
      document.getElementById('g_id_signin'),
      { theme: 'outline', size: 'large' }
    );
  } catch(e){
    statusEl.style.color = '#f33';
    statusEl.textContent = 'Google Identity indisponível.';
  }
}

function decodeJwt(token){
  try{
    const parts = token.split('.');
    if (parts.length < 2) return null;
    const payload = JSON.parse(atob(parts[1].replace(/-/g,'+').replace(/_/g,'/')));
    return payload;
  }catch(e){ return null; }
}

async function handleCredentialResponse(resp){
  const statusEl = document.getElementById('google_status');
  const payload = decodeJwt(resp.credential||'');
  if (!payload || !payload.email){
    statusEl.style.color = '#f33';
    statusEl.textContent = 'Falha ao obter email da conta.';
    return;
  }
  const email = (payload.email||'').toLowerCase();
  localStorage.setItem('js_user_email', email);
  statusEl.textContent = 'Logado como ' + email;
  try{
    await fetch('http://127.0.0.1:8787/api/set_owner', {
      method: 'POST',
      headers: {'Content-Type':'application/json'},
      body: JSON.stringify({email})
    });
  }catch(e){}
}
