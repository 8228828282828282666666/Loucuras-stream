# LoucurasStream na Samsung TV (Tizen)

Para rodar o **LoucurasStream** na sua Samsung TV, você precisará usar o **Tizen Studio**.

## Limitações Importantes

⚠️ **Atenção:** Como o app original foi feito em Python (`flet` + `yt-dlp`), ele **não roda nativamente** dentro da TV apenas copiando arquivos, pois a TV não tem Python instalado.

Para fazer funcionar na TV, a estratégia recomendada é:
1.  **Transformar em Web App:** O Flet pode gerar um site estático.
2.  **Hospedagem:** Hospedar o app em algum servidor.
3.  **Tizen Web App:** Criar um app Tizen que apenas carrega esse site.

## Arquivos Criados

Na pasta `tizen/`, criei os arquivos de configuração necessários para importar o projeto no Tizen Studio:

-   **config.xml**: O manifesto do aplicativo (define permissões, ícone, nome).
-   **.project**: Arquivo de projeto do Tizen Studio.
-   **index.html**: Página inicial básica.

## Como Importar no Tizen Studio

1.  Baixe e instale o [Tizen Studio](https://developer.tizen.org/development/tizen-studio/download).
2.  Abra o Tizen Studio.
3.  Vá em **File > Import > Tizen > Tizen Project**.
4.  Selecione "Root Directory" e escolha a pasta `LoucurasStream/tizen`.
5.  O projeto aparecerá na sua lista.
6.  Conecte sua TV no mesmo Wi-Fi do computador e configure o "Device Manager" no Tizen Studio.
7.  Clique com o botão direito no projeto e escolha **Run As > Tizen Web Application**.

## Alternativa Avançada (Flet Web)

Se você quiser tentar rodar a interface do Flet na TV:

1.  Gere a versão web do app:
    ```bash
    flet build web
    ```
2.  Copie o conteúdo da pasta `build/web` para dentro da pasta `tizen`.
3.  Edite o `config.xml` para garantir que `index.html` seja o ponto de entrada.
4.  **Nota:** As funções de download do YouTube (`yt-dlp`) provavelmente falharão devido às restrições de navegador da TV.
